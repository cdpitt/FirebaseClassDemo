package com.example.cody.firebaseclassdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ActivityPastEvents extends Activity implements Button.OnClickListener {

    private ListView listViewPastEvents;
    private TextView textView;


    private String[] TITLES = {"Long run","Quick run","Beer run","Fast Walk" };
    private String[] DATES = {"11/10","11/20","11/22","11/29"};
    private String [] TIMES = {"10am", "6pm", "3pm", "8pm"};
    private String[] STARTING = {"Woodbury Gardens","Ross","Burns Park","Munger"};
    private String[] RUNNERS = {"3 runners","5 runners","7 runners","2 runners"};

    ArrayList<String> list = new ArrayList<>();
    ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_past_events);

        listViewPastEvents = (ListView) findViewById(R.id.listViewPastEvents);

        textView = (TextView)findViewById(R.id.textView);
        String teste = CustomAdapter.eventTest;
        textView.setText(teste);


        class CustomAdapter extends BaseAdapter {
            @Override
            public int getCount() {

                return TITLES.length;}

            @Override
            public Object getItem(int i) {
                return null;
            }

            @Override
            public long getItemId(int i) {
                return 0;
            }

            @Override
            public View getView(int i, View view, ViewGroup viewGroup) {

                view = getLayoutInflater().inflate(R.layout.listviewpastevents,null);
                TextView textViewListEventsTitle = view.findViewById(R.id.textViewListEventsTitle);
                TextView textViewListEventsDate = view.findViewById(R.id.textViewListEventsDate);
                TextView textViewListEventsTime = view.findViewById(R.id.textViewListEventsTime);
                TextView textViewListEventsStartLocation = view.findViewById(R.id.textViewListEventsStartLocation);
                TextView textViewListEventsNumber = view.findViewById(R.id.textViewPastEventListNumber);


                textViewListEventsTitle.setText(TITLES[i]);
                textViewListEventsDate.setText(DATES[i]);
                textViewListEventsTime.setText(TIMES[i]);
                textViewListEventsStartLocation.setText(STARTING[i]);
                textViewListEventsNumber.setText(RUNNERS[i]);

                return view;
            }
        }

        CustomAdapter customAdapter = new CustomAdapter();
        listViewPastEvents.setAdapter(customAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater mainMenuInflater = getMenuInflater();
        mainMenuInflater.inflate(R.menu.mainmenu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menuitemHome) {
            Intent intentHome = new Intent(this, ActivityHome.class);
            this.startActivity(intentHome);
        } else if (item.getItemId() == R.id.menuitemEditProfile) {
            Intent intentEditProfile = new Intent(this, ActivityEditProfile.class);
            this.startActivity(intentEditProfile);
        } else if (item.getItemId() == R.id.menuitemSettings) {
            Intent intentSettings = new Intent(this, ActivitySettings.class);
            this.startActivity(intentSettings);
        } else if (item.getItemId() == R.id.menuitemLogout) {
            Intent intentLogout = new Intent(this, LoginActivity.class);
            this.startActivity(intentLogout);
        }

        return super.onOptionsItemSelected(item);
    }

}
