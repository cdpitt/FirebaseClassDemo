package com.example.cody.firebaseclassdemo;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

/**
 * Created by Cesar on 12/15/2017.
 */

public class FirebaseHelper {

    DatabaseReference eventRef;
    ArrayList<Event> listevents = new ArrayList<>();

   public FirebaseHelper(DatabaseReference db){

       this.eventRef = db;

   }



    private void fetchdata(DataSnapshot dataSnapshot)

    {

        for (DataSnapshot ds : dataSnapshot.getChildren()) {
            Event event = ds.getValue(Event.class);
            listevents.add(event);
        }
    }

    public ArrayList<Event> retrieve()
    {
        eventRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                fetchdata(dataSnapshot);

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                fetchdata(dataSnapshot);

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    return listevents;
    }


}
