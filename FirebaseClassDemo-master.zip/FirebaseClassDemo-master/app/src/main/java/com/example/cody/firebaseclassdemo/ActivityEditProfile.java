package com.example.cody.firebaseclassdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.solver.widgets.Snapshot;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ActivityEditProfile extends Activity implements View.OnClickListener {

    //define objects
    private Button buttonUpdateProfile;
    private EditText editTextFirstName;
    private EditText editTextLastName;
    private EditText editTextEmail;
    private EditText editTextUserBio;

    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        //connecting objects to UI
        editTextFirstName = findViewById(R.id.editTextFirstName);
        editTextLastName = findViewById(R.id.editTextLastName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextUserBio = findViewById(R.id.editTextUserBio);

        buttonUpdateProfile = findViewById(R.id.buttonUpdateProfile);

        buttonUpdateProfile.setOnClickListener(this);

        mAuth = FirebaseAuth.getInstance();
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        final DatabaseReference userRef = db.getReference("Users");

        editTextEmail.setText(mAuth.getCurrentUser().getEmail().toString());


        userRef.orderByChild("userEmail").equalTo(mAuth.getCurrentUser().getEmail().toString()).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                editTextFirstName.setText(dataSnapshot.getValue(User.class).userFirstName);
                editTextLastName.setText(dataSnapshot.getValue(User.class).userLastName);
                editTextUserBio.setText(dataSnapshot.getValue(User.class).userBio);

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });





    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater mainMenuInflater = getMenuInflater();
        mainMenuInflater.inflate(R.menu.mainmenu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onClick(View view) {
        mAuth = FirebaseAuth.getInstance();
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        final DatabaseReference userRef = db.getReference("Users");
        DatabaseReference searchRef = db.getReference("Users");
        //initializing Firebase database

//INCOMPLETE: this should update the fields of the user profile based on what is populated in Profile page
        if (view == buttonUpdateProfile) {
            final String updateFirstName = editTextFirstName.getText().toString();
            final String updateLastName = editTextLastName.getText().toString();
            final String updateBio = editTextUserBio.getText().toString();
            final String UpdateEmail = editTextEmail.getText().toString();



            searchRef.child(mAuth.getCurrentUser().getUid().toString()).orderByChild("userEmail").equalTo(UpdateEmail).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                        userRef.orderByChild("userEmail").equalTo(UpdateEmail).addChildEventListener(new ChildEventListener() {
                            @Override
                            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                                String userKey = dataSnapshot.getKey();


                                userRef.child(userKey).child("userBio").setValue(updateBio);
                                userRef.child(userKey).child("userFirstName").setValue(updateFirstName);
                                userRef.child(userKey).child("userLastName").setValue(updateLastName);

                                //Toast indicating that profile was updated
                                Toast.makeText(ActivityEditProfile.this, "Profile updated", Toast.LENGTH_SHORT).show();

                                Intent intentGoHome = new Intent(ActivityEditProfile.this, ActivityHome.class);
                                startActivity(intentGoHome);


                            }

                            @Override
                            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                            }

                            @Override
                            public void onChildRemoved(DataSnapshot dataSnapshot) {

                            }

                            @Override
                            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });


                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });





        }




    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menuitemHome) {
            Intent intentHome = new Intent(this, ActivityHome.class);
            this.startActivity(intentHome);
        } else if (item.getItemId() == R.id.menuitemEditProfile) {
            Intent intentEditProfile = new Intent(this, ActivityEditProfile.class);
            this.startActivity(intentEditProfile);
        } else if (item.getItemId() == R.id.menuitemSettings) {
            Intent intentSettings = new Intent(this, ActivitySettings.class);
            this.startActivity(intentSettings);
        } else if (item.getItemId() == R.id.menuitemLogout) {
            Intent intentLogout = new Intent(this, LoginActivity.class);
            this.startActivity(intentLogout);
        }

        return super.onOptionsItemSelected(item);
    }
}
