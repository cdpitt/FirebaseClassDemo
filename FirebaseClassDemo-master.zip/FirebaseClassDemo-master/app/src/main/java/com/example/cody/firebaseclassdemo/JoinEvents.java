package com.example.cody.firebaseclassdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class JoinEvents extends Activity {

    private TextView textViewTest, textViewJoinEventTitle, textViewJoinEventDate, textViewJoinEventTime,
            textViewJoinEventStartLocation, textViewJoinEventEndLocation, textViewJoinEventDuration,
            textViewJoinEventLimit, textViewJoinEventDescription;

    private Button butttonJoinEvent, buttonBackEvents;

    private FirebaseAuth mAuth;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_events);

        textViewJoinEventTitle = (TextView)findViewById(R.id.textViewJoinEventTitle);
        textViewJoinEventDate = (TextView) findViewById(R.id.textViewJoinEventDate);
        textViewJoinEventTime = (TextView) findViewById(R.id.textViewJoinEventTime);
        textViewJoinEventStartLocation = (TextView)findViewById(R.id.textViewJoinEventStartLocation);
        textViewJoinEventEndLocation = (TextView)findViewById(R.id.textViewJoinEventEndLocation);
        textViewJoinEventDuration = (TextView)findViewById(R.id.textViewJoinEventDuration);
        textViewJoinEventLimit = (TextView)findViewById(R.id.textViewJoinEventLimit);
        textViewJoinEventDescription = (TextView)findViewById(R.id.textViewJoinEventDescription);

        butttonJoinEvent = (Button)findViewById(R.id.buttonJoinEvent);
        buttonBackEvents = (Button) findViewById(R.id.buttonBackEvents);



        FirebaseDatabase db = FirebaseDatabase.getInstance();
        final DatabaseReference eventRef = db.getReference("Events");

        final String teste = CustomAdapter.eventTest;

        eventRef.orderByChild("eventTitle").equalTo(teste).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                eventRef.orderByChild("eventTitle").equalTo(teste).addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                        Event findEvent = new Event();
                        findEvent = new Event();
                        findEvent = dataSnapshot.getValue(Event.class);
                        textViewJoinEventTitle.setText(findEvent.eventTitle);
                        textViewJoinEventDate.setText("Date: "+findEvent.eventDate);
                        textViewJoinEventTime.setText("Start time: "+findEvent.eventStartTime);
                        textViewJoinEventStartLocation.setText("Starting at: "+findEvent.eventStartLocation);
                        textViewJoinEventEndLocation.setText("Ending at: " +findEvent.eventEndLocation);
                        textViewJoinEventDuration.setText("Duration: "+findEvent.eventDuration+" miles");
                        textViewJoinEventLimit.setText("Limit of ruuners: "+findEvent.eventLimit);
                        textViewJoinEventDescription.setText(findEvent.eventDescription);



                    }

                    @Override
                    public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onChildRemoved(DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        butttonJoinEvent.setOnClickListener(new View.OnClickListener() {
            final String teste = CustomAdapter.eventTest;
            @Override
            public void onClick(View view) {
                mAuth = FirebaseAuth.getInstance();

                eventRef.orderByChild("evenTitle").equalTo(teste).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        eventRef.orderByChild("eventTitle").equalTo(teste).addChildEventListener(new ChildEventListener() {
                            @Override
                            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                                if (dataSnapshot.getValue()==null){
                                    Toast.makeText(JoinEvents.this, "No data snapshot", Toast.LENGTH_SHORT).show();

                                }else {
                                    String eventID = dataSnapshot.getKey().toString();
                                    String userID = mAuth.getCurrentUser().getUid().toString();
                                    eventRef.child(eventID).child("eventParticipants").push().setValue(userID);
                                    Toast.makeText(JoinEvents.this, "Event Joined", Toast.LENGTH_SHORT).show();



                                }


                            }

                            @Override
                            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                            }

                            @Override
                            public void onChildRemoved(DataSnapshot dataSnapshot) {

                            }

                            @Override
                            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });





            }
        });

        buttonBackEvents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentBackEvents = new Intent(JoinEvents.this,ActivityFindEvents.class);
                startActivity(intentBackEvents);
            }
        });


    }
}
