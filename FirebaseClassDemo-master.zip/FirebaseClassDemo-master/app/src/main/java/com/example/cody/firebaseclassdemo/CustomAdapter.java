package com.example.cody.firebaseclassdemo;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.v4.view.LayoutInflaterCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Cesar on 12/15/2017.
 */

public class CustomAdapter extends BaseAdapter {
    ArrayList<Event> listevents;
    Context c;
    public static String eventTest;
    CreateIntent tester;


    public CustomAdapter(Context c, ArrayList<Event> listevents) {
        this.c = c;
        this.listevents = listevents;
    }

    public CustomAdapter(ArrayList<Event> listevents) {
        this.listevents = listevents;
    }

    @Override
    public int getCount() {
        return listevents.size();
    }

    @Override
    public Object getItem(int position) {
        return listevents.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        view = LayoutInflater.from(c).inflate(R.layout.listviewevents,null);
        TextView textViewListEventsTitle = view.findViewById(R.id.textViewListEventsTitle);
        TextView textViewListEventsDate = view.findViewById(R.id.textViewListEventsDate);
        TextView textViewListEventsTime = view.findViewById(R.id.textViewListEventsTime);
        TextView textViewListEventsStartLocation = view.findViewById(R.id.textViewListEventsStartLocation);
        TextView textViewEventListLimit = view.findViewById(R.id.textViewEventListLimit);


        final Event s= (Event) this.getItem(position);

        textViewListEventsTitle.setText(s.getEventTitle());
        textViewListEventsDate.setText(s.getEventDate());
        textViewListEventsTime.setText(s.getEventStartTime());
        textViewListEventsStartLocation.setText(s.getEventStartLocation());
        textViewEventListLimit.setText(s.getEventLimit());

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(c, s.getEventTitle(), Toast.LENGTH_SHORT).show();
                eventTest = s.getEventTitle();
                JoinEvents();




            }
        });
        return view;
    }


    private void JoinEvents(String...details){

        Intent intentJoinEvents = new Intent(c, JoinEvents.class);
        c.startActivity(intentJoinEvents);

    }
}
