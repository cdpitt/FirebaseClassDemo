package com.example.cody.firebaseclassdemo;

import java.sql.Array;
import java.util.ArrayList;

/**
 * Created by Noah on 12/7/2017.
 */

public class Event {
    //defining fields that should be available for all Events
    public String eventTitle, eventStartTime, eventDuration,
            eventStartLocation, eventEndLocation, eventLimit,
            /*CHANGE: specifically for eventInvites --> if we store Users on Events we could include this
            field as an array of Users once we create the Users object?*/
            eventInvites,
            eventDescription, eventDate, eventCreatedBy;

    public Object eventParticipants;
    //create function to make Events an object
    public Event() {
    }

    public void setEventCreatedBy(String eventCreatedBy) {
        this.eventCreatedBy = eventCreatedBy;
    }

    public String getEventCreatedBy() {

        return eventCreatedBy;
    }

    //define all attributes that are on an instance of an Events object
    public Event(String eventTitle, String eventStartTime, String eventDuration,
                 String eventStartLocation, String eventEndLocation, String eventLimit,
                 String eventDate, String eventDescription, String eventParticipants,String eventCreatedBy) {

        this.eventTitle = eventTitle;
        this.eventStartTime = eventStartTime;
        this.eventDuration = eventDuration;
        this.eventStartLocation = eventStartLocation;
        this.eventEndLocation = eventEndLocation;
        this.eventLimit = eventLimit;
        //CHANGE: again - change this to array of Users if we get the chance
        this.eventInvites = eventInvites;
        this.eventDescription = eventDescription;
        this.eventDate = eventDate;
        this.eventCreatedBy = eventCreatedBy;
        this.eventParticipants = eventParticipants;




    }

    public String getEventTitle() {
        return eventTitle;
    }

    public String getEventStartTime() {
        return eventStartTime;
    }

    public String getEventDuration() {
        return eventDuration;
    }

    public String getEventStartLocation() {
        return eventStartLocation;
    }

    public String getEventEndLocation() {
        return eventEndLocation;
    }

    public String getEventLimit() {
        return eventLimit;
    }

    public String getEventInvites() {
        return eventInvites;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public String getEventDate() {
        return eventDate;
    }



    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public void setEventStartTime(String eventStartTime) {
        this.eventStartTime = eventStartTime;
    }

    public void setEventDuration(String eventDuration) {
        this.eventDuration = eventDuration;
    }

    public void setEventStartLocation(String eventStartLocation) {
        this.eventStartLocation = eventStartLocation;
    }

    public void setEventEndLocation(String eventEndLocation) {
        this.eventEndLocation = eventEndLocation;
    }

    public void setEventLimit(String eventLimit) {
        this.eventLimit = eventLimit;
    }

    public void setEventInvites(String eventInvites) {
        this.eventInvites = eventInvites;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }
}
