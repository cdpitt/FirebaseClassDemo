package com.example.cody.firebaseclassdemo;

import android.app.Activity;
import android.content.Intent;

/**
 * Created by Cesar on 12/15/2017.
 */

public class CreateIntent extends Activity{

    public void MoveActivity(){
        Intent intentViewEvent = new Intent(this, JoinEvents.class);
        startActivity(intentViewEvent);




    }
}

